package com.example.a7team;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button activebtn = (Button)findViewById(R.id.activebtn);
        Button showbtn = (Button)findViewById(R.id.showbtn);

        activebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent activeIntent = new Intent(MenuActivity.this, ActiveActivity.class);
                MenuActivity.this.startActivity(activeIntent);
            }
        });

        showbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent showIntent = new Intent(MenuActivity.this, ShowActivity.class);
                MenuActivity.this.startActivity(showIntent);
            }
        });
    }
}